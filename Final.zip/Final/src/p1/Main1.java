package p1;
import java.sql.*;
import p1.MatlabControl;


public class Main1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Main1.getCon();

	}
	public static Connection getCon()
	{
		Connection conn = null;
		try{
			Class.forName("com.mysql.jdbc.Driver"); //load the driver
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/final","root","root");
			System.out.println("ok");
			//MatlabControl mc = new MatlabControl();
		        //mc.eval(new String("x=5"));
		}
		catch (Exception e)
		{
			System.out.println(e);
		}
		return conn;
	}

}
